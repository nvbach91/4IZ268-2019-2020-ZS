
$(document).ready(function(){
    if("geolocation" in navigator){
        navigator.geolocation.getCurrentPosition(function(position){ 
            console.log("Found your location \nLat : "+position.coords.latitude+" \nLang :"+ position.coords.longitude);
            
            const proxy=`https://cors-anywhere.herokuapp.com/`;
            const api= `${proxy}https://api.darksky.net/forecast/d74da5e758733f58f5e39d0e6a9f6de4/${position.coords.latitude},${position.coords.longitude}`;
            /*fetch(api)
            .then(response => {
                return response.json();
        
            })
            .then(data => {
                console.log(data);
            })*/
            console.log($(".location-timezone").load(api))
            
        });
	}else{
		console.log("Browser doesn't support geolocation!");
    }
  

console.log('latitude is' + 'andblj');
console.log('long');
console.log('my messagezc')
})