export class Search {
    artist: string;
    title: string;
  }
  