export class Result {
    lyrics: string;
    error: string;
  }
  